import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Calculator(),
    );
  }
}

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  String _output = "0";
  String _expression = ""; // New variable to store the current expression
  double num1 = 0;
  double num2 = 0;
  String operand = "";

  void buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == "AC") {
        _output = "0";
        _expression = "";
        num1 = 0;
        num2 = 0;
        operand = "";
      } else if (buttonText == "<") {
        if (_output.isNotEmpty) {
          _output = _output.substring(0, _output.length - 1);
          if (_output.isEmpty) {
            _output = "0";
          }
        }
      } else if (buttonText == "+" || buttonText == "-" || buttonText == "×" || buttonText == "÷") {
        num1 = double.parse(_output);
        operand = buttonText;
        _expression = _output + buttonText;
        _output = "0";
      } else if (buttonText == "%") {
        _output = (double.parse(_output) / 100).toString();
        _expression = _output + "%";
      } else if (buttonText == ".") {
        if (!_output.contains(".")) {
          _output += buttonText;
        }
      } else if (buttonText == "=") {
        // Calculate the result
        num2 = double.parse(_output);

        if (operand == "+") {
          _output = (num1 + num2).toString();
        } else if (operand == "-") {
          _output = (num1 - num2).toString();
        } else if (operand == "×") {
          _output = (num1 * num2).toString();
        } else if (operand == "÷") {
          _output = num2 != 0 ? (num1 / num2).toString() : "Error";  // Prevent division by zero
        }

        // Show the full expression with result
        _expression += num2.toString() + " = " + _output;

        // Reset operation
        num1 = 0;
        num2 = 0;
        operand = "";
      } else {
        // Add number
        _output = _output == "0" ? buttonText : _output + buttonText;
        _expression = operand.isEmpty ? _output : _expression + buttonText; // Update the expression
      }
    });
  }

  Widget buildButton(String buttonText, Color color) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(8.0),
        child: ElevatedButton(
          onPressed: () => buttonPressed(buttonText),
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.all(22.0),
            backgroundColor: color,
            shape: CircleBorder(),
          ),
          child: Text(
            buttonText,
            style: TextStyle(
              fontSize: 26.0,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: <Widget>[
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(vertical: 24.0, horizontal: 12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _expression,
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 24.0,
                  ),
                ),
                Text(
                  _output,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 48.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Divider(),
          ),
          Column(
            children: [
              Row(
                children: <Widget>[
                  buildButton("<", Colors.grey),
                  buildButton("AC",Color(0xFFB60D01)),
                  buildButton("%", Colors.grey),
                  buildButton("÷", Colors.orange),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("7", Colors.grey[850]!),
                  buildButton("8", Colors.grey[850]!),
                  buildButton("9", Colors.grey[850]!),
                  buildButton("×", Colors.orange),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("4", Colors.grey[850]!),
                  buildButton("5", Colors.grey[850]!),
                  buildButton("6", Colors.grey[850]!),
                  buildButton("-", Colors.orange),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton("1", Colors.grey[850]!),
                  buildButton("2", Colors.grey[850]!),
                  buildButton("3", Colors.grey[850]!),
                  buildButton("+", Colors.orange),
                ],
              ),
              Row(
                children: <Widget>[
                  buildButton(" ", Colors.grey[850]!),
                  buildButton("0", Colors.grey[850]!),
                  buildButton(".", Colors.grey[850]!),
                  buildButton("=", Colors.orange),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
